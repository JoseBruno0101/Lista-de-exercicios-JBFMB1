// JBFMB-36.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-36 - Conta de 1 a 10 usando while                           *");
    printf("\n******************************************************************************\n");

    int i = 1;

    printf("\n");
    while (i <= 10) {
        printf("%d\n", i);
        i++;
    }

    return 0;
}
