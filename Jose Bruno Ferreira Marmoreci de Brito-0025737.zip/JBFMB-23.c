// JBFMB-23.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-23 - Identifica o maior de dois numeros                     *");
    printf("\n******************************************************************************\n");

    float a, b;

    printf("\nDigite a pontuacao do atleta 1: ");
    scanf("%f", &a);
    printf("Digite a pontuacao do atleta 2: ");
    scanf("%f", &b);

    if (a > b)
        printf("\nA maior pontuacao foi do atleta 1: %.2f\n", a);
    else if (b > a)
        printf("\nA maior pontuacao foi do atleta 2: %.2f\n", b);
    else
        printf("\nOs dois atletas empataram com %.2f pontos.\n", a);

    return 0;
}
