// JBFMB-29.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-29 - Exibe os numeros pares entre 0 e 50                    *");
    printf("\n******************************************************************************\n");

    int i;

    printf("\nNumeros pares entre 0 e 50:\n");
    for (i = 0; i <= 50; i += 2)
        printf("%d ", i);
    printf("\n");

    return 0;
}
