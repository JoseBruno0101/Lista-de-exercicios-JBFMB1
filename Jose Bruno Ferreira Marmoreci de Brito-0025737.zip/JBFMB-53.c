// JBFMB-53.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-53 - Menu que pergunta se deseja sair ate digitar 's'       *");
    printf("\n******************************************************************************\n");

    char resposta;

    do {
        printf("\n--- MENU DE CADASTRO ---\n");
        printf("Operacao realizada com sucesso!\n");
        printf("Deseja sair? (s/n): ");
        scanf(" %c", &resposta);
    } while (resposta != 's' && resposta != 'S');

    printf("\nEncerrando o sistema...\n");

    return 0;
}
