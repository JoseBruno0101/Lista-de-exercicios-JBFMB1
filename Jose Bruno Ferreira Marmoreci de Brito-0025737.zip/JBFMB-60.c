// JBFMB-60.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-60 - Validador de dias uteis usando switch case             *");
    printf("\n******************************************************************************\n");

    int dia;

    printf("\nDigite o numero do dia (1=Domingo ... 7=Sabado): ");
    scanf("%d", &dia);

    switch (dia) {
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("\nDia Util. Acesso liberado para o trabalho.\n");
            break;
        case 1:
        case 7:
            printf("\nFim de Semana. Predio fechado.\n");
            break;
        default:
            printf("\nNumero de dia invalido.\n");
    }

    return 0;
}
