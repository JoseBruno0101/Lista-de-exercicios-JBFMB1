// JBFMB-54.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-54 - Valida um numero de dificuldade entre 1 e 5            *");
    printf("\n******************************************************************************\n");

    int nivel;

    do {
        printf("\nDigite o nivel de dificuldade (1 a 5): ");
        scanf("%d", &nivel);
        if (nivel < 1 || nivel > 5)
            printf("Valor invalido! Tente novamente.\n");
    } while (nivel < 1 || nivel > 5);

    printf("\nNivel selecionado: %d\n", nivel);

    return 0;
}
