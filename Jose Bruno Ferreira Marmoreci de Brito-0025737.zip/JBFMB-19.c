// JBFMB-19.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-19 - Ordena tres numeros em ordem crescente                 *");
    printf("\n******************************************************************************\n");

    float a, b, c, temp;

    printf("\nDigite tres numeros: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a > b) { temp = a; a = b; b = temp; }
    if (b > c) { temp = b; b = c; c = temp; }
    if (a > b) { temp = a; a = b; b = temp; }

    printf("\nOrdem crescente: %.2f, %.2f, %.2f\n", a, b, c);

    return 0;
}
