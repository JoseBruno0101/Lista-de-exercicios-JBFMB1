// JBFMB-48.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-48 - Menu com opcao de sair usando do...while               *");
    printf("\n******************************************************************************\n");

    int opcao;

    do {
        printf("\n1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1)
            printf("\nVoce escolheu a mensagem!\n");
        else if (opcao != 2)
            printf("\nOpcao invalida!\n");

    } while (opcao != 2);

    return 0;
}
