// JBFMB-39.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-39 - Solicita um numero ate que seja positivo               *");
    printf("\n******************************************************************************\n");

    int n;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    while (n <= 0) {
        printf("Numero invalido! Digite um numero positivo: ");
        scanf("%d", &n);
    }

    printf("\nNumero positivo aceito: %d\n", n);

    return 0;
}
