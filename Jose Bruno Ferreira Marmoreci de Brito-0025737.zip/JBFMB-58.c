// JBFMB-58.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-58 - Calculadora de bolso de 4 operacoes usando switch case *");
    printf("\n******************************************************************************\n");

    float a, b, resultado;
    char operacao;

    printf("\nDigite o primeiro numero: ");
    scanf("%f", &a);
    printf("Digite a operacao (+, -, *, /): ");
    scanf(" %c", &operacao);
    printf("Digite o segundo numero: ");
    scanf("%f", &b);

    switch (operacao) {
        case '+':
            resultado = a + b;
            printf("\nResultado: %.2f\n", resultado);
            break;
        case '-':
            resultado = a - b;
            printf("\nResultado: %.2f\n", resultado);
            break;
        case '*':
            resultado = a * b;
            printf("\nResultado: %.2f\n", resultado);
            break;
        case '/':
            if (b != 0) {
                resultado = a / b;
                printf("\nResultado: %.2f\n", resultado);
            } else {
                printf("\nErro: divisao por zero!\n");
            }
            break;
        default:
            printf("\nOperacao matematica nao reconhecida\n");
    }

    return 0;
}
