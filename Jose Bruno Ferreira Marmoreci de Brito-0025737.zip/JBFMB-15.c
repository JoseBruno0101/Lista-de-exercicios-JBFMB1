// JBFMB-15.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-15 - Calcula quantas caixas cabem dentro do caminhao        *");
    printf("\n******************************************************************************\n");

    float compCam, largCam, altCam;
    float compCx, largCx, altCx;
    float volCam, volCx;
    int caixas;

    printf("\nDigite as dimensoes do caminhao (comprimento, largura, altura) em metros: ");
    scanf("%f %f %f", &compCam, &largCam, &altCam);

    printf("Digite as dimensoes da caixa (comprimento, largura, altura) em metros: ");
    scanf("%f %f %f", &compCx, &largCx, &altCx);

    volCam = compCam * largCam * altCam;
    volCx  = compCx  * largCx  * altCx;

    caixas = (int)(volCam / volCx);

    printf("\nVolume do caminhao: %.2f m3\n", volCam);
    printf("Volume da caixa: %.4f m3\n", volCx);
    printf("Cabem %d caixas dentro do caminhao.\n", caixas);

    return 0;
}
