// JBFMB-14.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-14 - Verifica o tipo de triangulo (Equilatero/Isosceles/Escaleno)*");
    printf("\n******************************************************************************\n");

    float a, b, c;

    printf("\nDigite os tres lados do triangulo: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a == b && b == c)
        printf("\nTriangulo Equilatero\n");
    else if (a == b || a == c || b == c)
        printf("\nTriangulo Isosceles\n");
    else
        printf("\nTriangulo Escaleno\n");

    return 0;
}
