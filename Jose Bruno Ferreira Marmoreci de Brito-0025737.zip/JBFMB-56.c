// JBFMB-56.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-56 - Menu do fast-food digital usando switch case           *");
    printf("\n******************************************************************************\n");

    int opcao;

    printf("\n--- TOTEM DE AUTOATENDIMENTO ---\n");
    printf("1 - Combo Hamburguer\n");
    printf("2 - Combo Pizza Brotinho\n");
    printf("3 - Combo Salada\n");
    printf("4 - Combo Balde de Frango\n");
    printf("Digite o numero do combo: ");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1:
            printf("\nCombo Hamburguer + Batata + Refri - R$ 30,00\n");
            break;
        case 2:
            printf("\nCombo Pizza Brotinho + Refri - R$ 25,00\n");
            break;
        case 3:
            printf("\nCombo Salada + Suco Natural - R$ 22,00\n");
            break;
        case 4:
            printf("\nCombo Balde de Frango + Molho - R$ 35,00\n");
            break;
        default:
            printf("\nOpcao invalida! Escolha de 1 a 4.\n");
    }

    return 0;
}
