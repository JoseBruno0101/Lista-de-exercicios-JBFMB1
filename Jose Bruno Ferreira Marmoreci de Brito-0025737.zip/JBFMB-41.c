// JBFMB-41.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-41 - Verifica se um numero e primo usando while             *");
    printf("\n******************************************************************************\n");

    int n, i = 2, divisores = 0;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    while (i < n) {
        if (n % i == 0)
            divisores++;
        i++;
    }

    if (divisores == 0 && n > 1)
        printf("\n%d e PRIMO.\n", n);
    else
        printf("\n%d NAO e primo.\n", n);

    return 0;
}
