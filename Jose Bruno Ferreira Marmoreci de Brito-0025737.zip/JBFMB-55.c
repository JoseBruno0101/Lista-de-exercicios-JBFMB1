// JBFMB-55.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-55 - Le numeros e mostra o maior, ate digitar um negativo   *");
    printf("\n******************************************************************************\n");

    int n, maior = 0;

    printf("\nDigite numeros positivos (digite um negativo para parar):\n");
    do {
        scanf("%d", &n);
        if (n > maior)
            maior = n;
    } while (n >= 0);

    printf("\nO maior numero positivo informado foi: %d\n", maior);

    return 0;
}
