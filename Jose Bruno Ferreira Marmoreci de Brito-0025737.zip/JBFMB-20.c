// JBFMB-20.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-20 - Verifica se o ano e bissexto                           *");
    printf("\n******************************************************************************\n");

    int ano;

    printf("\nDigite o ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0)
        printf("\n%d e um ano bissexto.\n", ano);
    else
        printf("\n%d nao e um ano bissexto.\n", ano);

    return 0;
}
