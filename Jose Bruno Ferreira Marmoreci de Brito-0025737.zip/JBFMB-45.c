// JBFMB-45.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-45 - Exibe um menu ate que a opcao sair seja escolhida      *");
    printf("\n******************************************************************************\n");

    int opcao = 0;

    while (opcao != 3) {
        printf("\n--- MENU ---\n");
        printf("1 - Opcao 1\n");
        printf("2 - Opcao 2\n");
        printf("3 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1)
            printf("\nVoce escolheu a Opcao 1.\n");
        else if (opcao == 2)
            printf("\nVoce escolheu a Opcao 2.\n");
        else if (opcao != 3)
            printf("\nOpcao invalida!\n");
    }

    printf("\nSaindo do sistema...\n");

    return 0;
}
