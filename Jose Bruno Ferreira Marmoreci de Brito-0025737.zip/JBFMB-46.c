// JBFMB-46.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-46 - Conta de 1 a 10 usando do...while                      *");
    printf("\n******************************************************************************\n");

    int i = 1;

    printf("\n");
    do {
        printf("%d\n", i);
        i++;
    } while (i <= 10);

    return 0;
}
