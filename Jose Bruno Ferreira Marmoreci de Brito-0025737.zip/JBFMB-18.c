// JBFMB-18.c
#include <stdio.h>
#include <string.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-18 - Login simples para a biblioteca digital                *");
    printf("\n******************************************************************************\n");

    char usuario[50], senha[50];
    const char usuarioCorreto[] = "aluno";
    const char senhaCorreta[]   = "1234";

    printf("\nDigite o usuario: ");
    scanf("%s", usuario);
    printf("Digite a senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, usuarioCorreto) == 0 && strcmp(senha, senhaCorreta) == 0)
        printf("\nAcesso permitido!\n");
    else
        printf("\nAcesso negado!\n");

    return 0;
}
