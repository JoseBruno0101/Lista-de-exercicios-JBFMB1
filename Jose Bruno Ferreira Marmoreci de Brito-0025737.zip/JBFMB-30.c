// JBFMB-30.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-30 - Calcula o fatorial de um numero usando for             *");
    printf("\n******************************************************************************\n");

    int n, i;
    long long fatorial = 1;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
        fatorial *= i;

    printf("\n%d! = %lld\n", n, fatorial);

    return 0;
}
