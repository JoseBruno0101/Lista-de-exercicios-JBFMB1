// JBFMB-49.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-49 - Pede a senha ate acertar (do...while)                  *");
    printf("\n******************************************************************************\n");

    int senha;
    const int senhaCorreta = 1111;

    do {
        printf("\nDigite a senha: ");
        scanf("%d", &senha);
    } while (senha != senhaCorreta);

    printf("\nAcesso liberado!\n");

    return 0;
}
