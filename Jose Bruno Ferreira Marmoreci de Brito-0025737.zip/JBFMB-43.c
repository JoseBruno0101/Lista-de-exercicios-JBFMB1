// JBFMB-43.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-43 - Soma os numeros pares entre 1 e 100 usando while       *");
    printf("\n******************************************************************************\n");

    int i = 1, soma = 0;

    while (i <= 100) {
        if (i % 2 == 0)
            soma += i;
        i++;
    }

    printf("\nA soma dos numeros pares entre 1 e 100 e: %d\n", soma);

    return 0;
}
