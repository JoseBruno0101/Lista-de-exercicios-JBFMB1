// JBFMB-28.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-28 - Soma dos 100 primeiros numeros naturais                *");
    printf("\n******************************************************************************\n");

    int i, soma = 0;

    for (i = 1; i <= 100; i++)
        soma += i;

    printf("\nA soma dos numeros de 1 a 100 e: %d\n", soma);

    return 0;
}
