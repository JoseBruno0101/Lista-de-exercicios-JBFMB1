// JBFMB-57.c
#include <stdio.h>
#include <string.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-57 - Fala do urso de pelucia eletronico conforme a cor      *");
    printf("\n******************************************************************************\n");

    char cor[20];

    printf("\nDigite a cor que acendeu (Verde, Amarelo ou Vermelho): ");
    scanf("%s", cor);

    if (strcmp(cor, "Verde") == 0)
        printf("\nO urso diz: Vamos brincar la fora!\n");
    else if (strcmp(cor, "Amarelo") == 0)
        printf("\nO urso diz: Estou ficando com soninho...\n");
    else if (strcmp(cor, "Vermelho") == 0)
        printf("\nO urso diz: Estou com fome, hora do lanche!\n");
    else
        printf("\nCor desconhecida\n");

    return 0;
}
