// JBFMB-44.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-44 - Conta a quantidade de digitos de um numero             *");
    printf("\n******************************************************************************\n");

    int n, contador = 0;

    printf("\nDigite um numero positivo: ");
    scanf("%d", &n);

    if (n == 0)
        contador = 1;

    while (n > 0) {
        n = n / 10;
        contador++;
    }

    printf("\nO numero possui %d digito(s).\n", contador);

    return 0;
}
