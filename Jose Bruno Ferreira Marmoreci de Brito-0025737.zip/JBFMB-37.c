// JBFMB-37.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-37 - Soma numeros digitados ate que seja digitado zero      *");
    printf("\n******************************************************************************\n");

    int n, soma = 0;

    printf("\nDigite numeros (0 para parar): ");
    scanf("%d", &n);

    while (n != 0) {
        soma += n;
        scanf("%d", &n);
    }

    printf("\nA soma total foi: %d\n", soma);

    return 0;
}
