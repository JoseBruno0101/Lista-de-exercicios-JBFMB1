// JBFMB-34.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-34 - Verifica se um numero e primo usando for               *");
    printf("\n******************************************************************************\n");

    int n, i, primo = 1;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    if (n < 2)
        primo = 0;

    for (i = 2; i < n && primo == 1; i++)
        if (n % i == 0)
            primo = 0;

    if (primo == 1)
        printf("\n%d e PRIMO.\n", n);
    else
        printf("\n%d NAO e primo.\n", n);

    return 0;
}
