// JBFMB-38.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-38 - Solicita a senha ate que seja digitada corretamente    *");
    printf("\n******************************************************************************\n");

    int senha;
    const int senhaCorreta = 1111;

    printf("\nDigite a senha: ");
    scanf("%d", &senha);

    while (senha != senhaCorreta) {
        printf("Senha incorreta! Tente novamente: ");
        scanf("%d", &senha);
    }

    printf("\nAcesso liberado!\n");

    return 0;
}
