// JBFMB-22.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-22 - Verifica se um numero e par ou impar                   *");
    printf("\n******************************************************************************\n");

    int n;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    if (n % 2 == 0)
        printf("\n%d e PAR.\n", n);
    else
        printf("\n%d e IMPAR.\n", n);

    return 0;
}
