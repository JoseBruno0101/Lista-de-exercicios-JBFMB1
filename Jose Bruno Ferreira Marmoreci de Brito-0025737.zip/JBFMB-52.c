// JBFMB-52.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-52 - Soma valores ate que o numero digitado seja multiplo de 10*");
    printf("\n******************************************************************************\n");

    int n, soma = 0;

    printf("\nDigite numeros (a soma para quando digitar um multiplo de 10):\n");
    do {
        scanf("%d", &n);
        soma += n;
    } while (n % 10 != 0);

    printf("\nA soma total foi: %d\n", soma);

    return 0;
}
