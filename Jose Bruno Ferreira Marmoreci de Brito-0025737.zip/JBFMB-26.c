// JBFMB-26.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-26 - Conta de 1 a 10 usando for                             *");
    printf("\n******************************************************************************\n");

    int i;

    printf("\n");
    for (i = 1; i <= 10; i++)
        printf("%d\n", i);

    return 0;
}
