// JBFMB-24.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-24 - Verifica se a pessoa pode votar                        *");
    printf("\n******************************************************************************\n");

    int idade;

    printf("\nDigite sua idade: ");
    scanf("%d", &idade);

    if (idade < 16)
        printf("\nVoce nao pode votar.\n");
    else if (idade < 18 || idade >= 70)
        printf("\nVoto facultativo.\n");
    else
        printf("\nVoto obrigatorio.\n");

    return 0;
}
