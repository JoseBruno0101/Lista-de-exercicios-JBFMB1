// JBFMB-35.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-35 - Mostra os n primeiros termos da sequencia de Fibonacci *");
    printf("\n******************************************************************************\n");

    int n, i, a = 0, b = 1, c;

    printf("\nDigite a quantidade de termos: ");
    scanf("%d", &n);

    printf("\nSequencia de Fibonacci: ");
    for (i = 0; i < n; i++) {
        printf("%d ", a);
        c = a + b;
        a = b;
        b = c;
    }
    printf("\n");

    return 0;
}
