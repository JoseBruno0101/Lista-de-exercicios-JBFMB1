// JBFMB-32.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-32 - Mostra o quadrado dos numeros de 1 a 10                *");
    printf("\n******************************************************************************\n");

    int i;

    printf("\n");
    for (i = 1; i <= 10; i++)
        printf("%d ao quadrado = %d\n", i, i * i);

    return 0;
}
