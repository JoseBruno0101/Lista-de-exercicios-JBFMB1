// JBFMB-40.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-40 - Mostra a tabuada de um numero usando while             *");
    printf("\n******************************************************************************\n");

    int n, i = 1;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    printf("\n");
    while (i <= 10) {
        printf("%d x %d = %d\n", n, i, n * i);
        i++;
    }

    return 0;
}
