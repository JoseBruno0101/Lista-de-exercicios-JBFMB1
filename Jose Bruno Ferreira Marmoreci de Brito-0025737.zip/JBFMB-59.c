// JBFMB-59.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-59 - Comando de voz do robo de entregas usando switch case  *");
    printf("\n******************************************************************************\n");

    char letra;

    printf("\nDigite a letra indicada na placa (N, S, L, O): ");
    scanf(" %c", &letra);

    switch (letra) {
        case 'N':
            printf("\nSeguir para o Norte.\n");
            break;
        case 'S':
            printf("\nSeguir para o Sul.\n");
            break;
        case 'L':
            printf("\nVirar a Leste (Direita).\n");
            break;
        case 'O':
            printf("\nVirar a Oeste (Esquerda).\n");
            break;
        default:
            printf("\nComando invalido! Pare o robo.\n");
    }

    return 0;
}
