// JBFMB-47.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-47 - Mostra a tabuada de um numero usando do...while        *");
    printf("\n******************************************************************************\n");

    int n, i = 1;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    printf("\n");
    do {
        printf("%d x %d = %d\n", n, i, n * i);
        i++;
    } while (i <= 10);

    return 0;
}
