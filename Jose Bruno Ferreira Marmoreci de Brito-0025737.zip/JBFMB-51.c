// JBFMB-51.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-51 - Contagem regressiva de 10 ate 1 usando do...while      *");
    printf("\n******************************************************************************\n");

    int i = 10;

    printf("\n");
    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);

    printf("Largada!\n");

    return 0;
}
