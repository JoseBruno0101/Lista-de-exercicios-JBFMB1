// JBFMB-50.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-50 - Exige numero positivo usando do...while                *");
    printf("\n******************************************************************************\n");

    float valor;

    do {
        printf("\nDigite um valor positivo para deposito: ");
        scanf("%f", &valor);
        if (valor <= 0)
            printf("Valor invalido! Tente novamente.\n");
    } while (valor <= 0);

    printf("\nDeposito de R$ %.2f realizado com sucesso!\n", valor);

    return 0;
}
