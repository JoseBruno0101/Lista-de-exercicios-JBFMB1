// JBFMB-31.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-31 - Contagem regressiva de 10 ate 1                        *");
    printf("\n******************************************************************************\n");

    int i;

    printf("\n");
    for (i = 10; i >= 1; i--)
        printf("%d\n", i);
    printf("Largada!\n");

    return 0;
}
