// JBFMB-21.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-21 - Classifica um numero em positivo, negativo ou zero     *");
    printf("\n******************************************************************************\n");

    float valor;

    printf("\nDigite um valor: ");
    scanf("%f", &valor);

    if (valor > 0)
        printf("\nValor positivo (lucro).\n");
    else if (valor < 0)
        printf("\nValor negativo (prejuizo).\n");
    else
        printf("\nValor igual a zero.\n");

    return 0;
}
