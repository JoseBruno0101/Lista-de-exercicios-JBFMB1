// JBFMB-33.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-33 - Lista os multiplos de 3 entre 1 e 30                   *");
    printf("\n******************************************************************************\n");

    int i;

    printf("\nMultiplos de 3 entre 1 e 30:\n");
    for (i = 1; i <= 30; i++)
        if (i % 3 == 0)
            printf("%d ", i);
    printf("\n");

    return 0;
}
