// JBFMB-42.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-42 - Conta quantos numeros impares foram digitados (10 numeros)*");
    printf("\n******************************************************************************\n");

    int n, contador = 0, i = 0;

    printf("\nDigite 10 numeros:\n");
    while (i < 10) {
        scanf("%d", &n);
        if (n % 2 != 0)
            contador++;
        i++;
    }

    printf("\nForam digitados %d numeros impares.\n", contador);

    return 0;
}
