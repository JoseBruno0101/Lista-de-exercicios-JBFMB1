// JBFMB-16.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-16 - Verifica multiplo de 3 e/ou 5 - premio da lanchonete   *");
    printf("\n******************************************************************************\n");

    int pedido;

    printf("\nDigite o numero do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0)
        printf("\nParabens! Pedido multiplo de 3 e 5: voce ganhou refrigerante e sobremesa!\n");
    else if (pedido % 3 == 0)
        printf("\nParabens! Voce ganhou um refrigerante!\n");
    else if (pedido % 5 == 0)
        printf("\nParabens! Voce ganhou uma sobremesa!\n");
    else
        printf("\nQue pena, esse pedido nao ganhou nenhum brinde.\n");

    return 0;
}
