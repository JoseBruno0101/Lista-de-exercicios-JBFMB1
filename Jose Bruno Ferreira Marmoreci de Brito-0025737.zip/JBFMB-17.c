// JBFMB-17.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-17 - Sensor de altura da montanha-russa                     *");
    printf("\n******************************************************************************\n");

    float altura;

    printf("\nDigite a altura da crianca (cm): ");
    scanf("%f", &altura);

    if (altura >= 140.0)
        printf("\nLuz VERDE: liberado para entrar no brinquedo!\n");
    else
        printf("\nLuz VERMELHA: barrado, altura insuficiente!\n");

    return 0;
}
