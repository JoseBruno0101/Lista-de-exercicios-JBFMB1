// JBFMB-25.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-25 - Verifica aprovacao, recuperacao ou reprovacao          *");
    printf("\n******************************************************************************\n");

    float media;

    printf("\nDigite a media final do aluno: ");
    scanf("%f", &media);

    if (media >= 7.0)
        printf("\nAluno APROVADO.\n");
    else if (media >= 5.0)
        printf("\nAluno em RECUPERACAO.\n");
    else
        printf("\nAluno REPROVADO.\n");

    return 0;
}
