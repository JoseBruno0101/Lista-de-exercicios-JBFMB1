// JBFMB-27.c
#include <stdio.h>

int main() {
    printf("\n******************************************************************************");
    printf("\n* Aluno: JOSE BRUNO FERREIRA MARMORECI DE BRITO - RA 0025737                 *");
    printf("\n* Programa JBFMB-27 - Mostra a tabuada de um numero usando for               *");
    printf("\n******************************************************************************\n");

    int n, i;

    printf("\nDigite um numero: ");
    scanf("%d", &n);

    printf("\n");
    for (i = 1; i <= 10; i++)
        printf("%d x %d = %d\n", n, i, n * i);

    return 0;
}
